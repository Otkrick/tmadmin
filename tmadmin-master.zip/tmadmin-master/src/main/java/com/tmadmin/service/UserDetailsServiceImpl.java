package com.tmadmin.service;

import com.tmadmin.model.Credentials;
import com.tmadmin.model.User;
import com.tmadmin.repository.UserRepository;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.experimental.FieldDefaults;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@AllArgsConstructor
@FieldDefaults(makeFinal = true, level = AccessLevel.PRIVATE)
public class UserDetailsServiceImpl implements UserDetailsService {

    private final UserRepository userRepository;

    @Transactional
    @Override
    public UserDetails loadUserByUsername(String name){
        User user = userRepository.findByUserName(name)
                .orElseThrow(() -> new UsernameNotFoundException("There is no user with name : " + name));

        return new Credentials(user);
    }
}
