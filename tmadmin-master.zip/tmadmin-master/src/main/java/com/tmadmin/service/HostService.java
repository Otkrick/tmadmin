package com.tmadmin.service;

import com.tmadmin.dto.HostDto;
import com.tmadmin.mapper.HostMapper;
import com.tmadmin.model.Host;
import com.tmadmin.repository.HostRepository;
import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@FieldDefaults(level = AccessLevel.PRIVATE)
public class HostService extends CrudService<Host, HostDto> {

    public HostService(HostRepository hostRepository, HostMapper hostMapper) {
        super(hostRepository, hostMapper);
    }

}
