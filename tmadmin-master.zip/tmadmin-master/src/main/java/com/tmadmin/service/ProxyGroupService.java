package com.tmadmin.service;

import com.tmadmin.dto.proxygroup.ProxyGroupDto;
import com.tmadmin.dto.proxygroup.ProxyId;
import com.tmadmin.exception.ResourceNotFoundException;
import com.tmadmin.mapper.ProxyGroupMapper;
import com.tmadmin.model.Proxy;
import com.tmadmin.model.ProxyGroup;
import com.tmadmin.repository.ProxyGroupRepository;
import com.tmadmin.repository.ProxyRepository;
import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
@FieldDefaults(level = AccessLevel.PRIVATE)
public class ProxyGroupService extends CrudService<ProxyGroup, ProxyGroupDto> {

    final ProxyGroupRepository proxyGroupRepository;
    final ProxyRepository proxyRepository;

    @Autowired
    public ProxyGroupService(ProxyGroupRepository proxyGroupRepository, ProxyGroupMapper proxyGroupMapper,
                             ProxyRepository proxyRepository) {
        super(proxyGroupRepository, proxyGroupMapper);
        this.proxyGroupRepository = proxyGroupRepository;
        this.proxyRepository = proxyRepository;
    }

    @Transactional
    public String deleteProxyFromList(Long id, List<ProxyId> proxyIdList) {
        ProxyGroup proxyGroup = proxyGroupRepository.findById(id).orElseThrow(() ->
                new ResourceNotFoundException("Proxy Group", "id", id));
        List<Long> longList = proxyIdList.stream()
                .map(ProxyId::getProxyId)
                .collect(Collectors.toList());
        List<Proxy> newProxyList = proxyRepository.findAllById(longList);
        List<Proxy> proxyList = proxyGroup.getProxyList();
        proxyList.removeAll(newProxyList);
        proxyGroup.setProxyList(proxyList);
        proxyGroupRepository.save(proxyGroup);
        return "Proxy/ies deleted from group";
    }

    @Transactional
    public String addProxyToList(Long id, List<ProxyId> proxyIdList) {
        ProxyGroup proxyGroup = proxyGroupRepository.findById(id).orElseThrow(() ->
                new ResourceNotFoundException("Proxy Group", "id", id));
        List<Long> longList = proxyIdList.stream()
                .map(ProxyId::getProxyId)
                .collect(Collectors.toList());
        List<Proxy> newProxyList = proxyRepository.findAllById(longList);
        List<Proxy> proxyList = proxyGroup.getProxyList();
        for (Proxy proxy : newProxyList) {
            if (!proxyList.contains(proxy)) {
                proxyList.add(proxy);
            }
        }
        log.info("list " +proxyList);
        proxyGroup.setProxyList(proxyList);
        proxyGroupRepository.save(proxyGroup);
        return "Proxy/ies added to group";
    }

}
