package com.tmadmin.service;

import com._1c.v8.ibis.admin.IClusterInfo;
import com._1c.v8.ibis.admin.IInfoBaseInfo;
import com._1c.v8.ibis.admin.IInfoBaseInfoShort;
import com._1c.v8.ibis.admin.InfoBaseInfo;
import com.tmadmin.dto.EnterpriseDto;
import com.tmadmin.dto.InfoBaseInfoDto;
import com.tmadmin.mapper.InfoBaseInfoMapper;
import com.tmadmin.util.AgentAdminUtil;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.experimental.FieldDefaults;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

@Slf4j
@AllArgsConstructor
@Service
@FieldDefaults(level = AccessLevel.PRIVATE)
public class EnterpriseService {

    final AgentAdminUtil agentAdminUtil;
    final InfoBaseInfoMapper infoBaseInfoMapper;

    public List<IInfoBaseInfoShort> getBaseInfoShort(EnterpriseDto enterpriseDto) {
        UUID uuid = UUID.fromString(enterpriseDto.getUuid());
        agentAdminUtil.connect("194.55.234.39", 1545, 0);
        agentAdminUtil.addAuthentication(uuid, "test", "test");
        agentAdminUtil.authenticate(uuid, enterpriseDto.getLogin(), enterpriseDto.getPassword());
        return agentAdminUtil.getInfoBasesShort(uuid);
    }

    public List<IClusterInfo> getClusterInfoList() {
        agentAdminUtil.connect("194.55.234.39", 1545, 0);
        return agentAdminUtil.getClusterInfoList();
    }

    public IInfoBaseInfo getBaseInfo(String clusterId, String infoBaseId) {
        UUID clusterUuid = UUID.fromString(clusterId);
        UUID infoBaseUuid = UUID.fromString(infoBaseId);
        agentAdminUtil.connect("194.55.234.39", 1545, 0);
        agentAdminUtil.authenticate(clusterUuid, "test", "test");
        agentAdminUtil.addAuthentication(clusterUuid, "test", "Q123456-");
        return agentAdminUtil.getInfoBaseInfo(clusterUuid, infoBaseUuid);
    }

    public void createInfoBase(InfoBaseInfoDto infoBaseInfoDto) {
        if (infoBaseInfoDto.getInfoBaseId() == null) {
            infoBaseInfoDto.setInfoBaseId(new UUID(0L, 0L));
        }
        UUID clusterUuid = UUID.fromString("fa08883d-a01a-4b3c-9d95-38587afe8593");
        agentAdminUtil.connect("194.55.234.39", 1545, 0);
        agentAdminUtil.authenticate(clusterUuid, "test", "test");
        InfoBaseInfo infoBaseInfo = infoBaseInfoMapper.toModel(infoBaseInfoDto);
        agentAdminUtil.createInfoBase(clusterUuid, infoBaseInfo, 1);
    }
}