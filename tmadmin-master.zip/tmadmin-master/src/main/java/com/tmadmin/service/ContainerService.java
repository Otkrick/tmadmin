package com.tmadmin.service;

import com.tmadmin.dto.ContainerDto;
import com.tmadmin.mapper.ContainerMapper;
import com.tmadmin.model.Container;
import com.tmadmin.repository.ContainerRepository;
import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@FieldDefaults(level = AccessLevel.PRIVATE)
public class ContainerService extends CrudService<Container, ContainerDto> {

    public ContainerService(ContainerRepository containerRepository, ContainerMapper containerMapper) {
        super(containerRepository, containerMapper);
    }

}
