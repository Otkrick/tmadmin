package com.tmadmin.service;

import com.tmadmin.exception.ResourceNotFoundException;
import com.tmadmin.mapper.CrudMapper;
import com.tmadmin.model.BaseModel;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.experimental.FieldDefaults;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public abstract class CrudService<T extends BaseModel, D> {

    final JpaRepository<T, Long> jpaRepository;
    final CrudMapper<T, D> crudMapper;

    @Transactional
    public List<T> findAll() {
        return jpaRepository.findAll();
    }

    @Transactional
    public String saveNew(D dto) {
        jpaRepository.save(crudMapper.toModel(dto));
        return "saved";
    }

    @Transactional
    public T findById(Long id) {
        return jpaRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Resource", "id", id));
    }

    @Transactional
    public String update(Long id, D dto) {
        Optional<T> optional = jpaRepository.findById(id);
        if (optional.isPresent()) {
            T t = crudMapper.toModel(dto);
            t.setId(id);
            jpaRepository.save(t);
        } else {
            throw new ResourceNotFoundException("Resource", "id", id);
        }
        return "updated";
    }

    @Transactional
    public String delete(Long id) {
        jpaRepository.deleteById(id);
        return "deleted!";
    }

}
