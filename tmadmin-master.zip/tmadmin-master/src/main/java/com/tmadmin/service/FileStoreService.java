package com.tmadmin.service;

import com.tmadmin.dto.FileStoreDto;
import com.tmadmin.exception.ResourceNotFoundException;
import com.tmadmin.mapper.FileStoreMapper;
import com.tmadmin.model.FileStore;
import com.tmadmin.repository.FileStoreRepository;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.experimental.FieldDefaults;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FileUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

@Slf4j
@AllArgsConstructor
@Service
@FieldDefaults(level = AccessLevel.PRIVATE)
public class FileStoreService {

    FileStoreRepository fileStoreRepository;
    FileStoreMapper fileStoreMapper;

    @Transactional
    public void saveFile(MultipartFile multipartFile, Boolean config) {
        if (config == null) {
            config = false;
        }
        if (multipartFile == null) {
            throw new ResourceNotFoundException("File", "...", "...");
        }
        FileStore fileStore = new FileStore();
        try {
            log.info("Multipart file = " + multipartFile.getOriginalFilename());
            fileStore.setData(multipartFile.getBytes());
            fileStore.setUuid(getUuid());
            fileStore.setPath(multipartFile.getOriginalFilename());
            fileStore.setConfig(config);
            fileStoreRepository.save(fileStore);
        } catch (IOException e) {
            log.info("MultipartFile to Blob exception. " + e);
        }
    }

    String getUuid() {
        String uuid = UUID.randomUUID().toString();
        if (fileStoreRepository.findByUuid(uuid).isPresent()) {
            return getUuid();
        }
        return uuid;
    }

    @Transactional
    public File findFile(String uuid) {
        Optional<FileStore> fileStoreOptional = fileStoreRepository.findByUuid(uuid);
        if (fileStoreOptional.isPresent()) {
            if (fileStoreOptional.get().getConfig()) {
                throw new ResourceNotFoundException("File", "uuid", uuid);
            }
            FileStore fileStore = fileStoreOptional.get();
            byte[] data = fileStore.getData();
            try {
                File file = new File(fileStore.getPath());
                FileUtils.writeByteArrayToFile(file, data);
                return file;
            } catch (IOException e) {
                throw new ResourceNotFoundException("File", "uuid", uuid);
            }
        }
        throw new ResourceNotFoundException("File", "uuid", uuid);
    }

    @Transactional
    public List<FileStoreDto> findAll() {
        return fileStoreRepository.findAll().stream()
                .map(fileStore -> fileStoreMapper.toFileStoreDto(fileStore))
                .collect(Collectors.toList());
    }

    @Transactional
    public void delete(Long id) {
        fileStoreRepository.deleteById(id);
    }

}
