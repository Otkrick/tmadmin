package com.tmadmin.service;

import com.tmadmin.dto.ClientDto;
import com.tmadmin.mapper.ClientMapper;
import com.tmadmin.mapper.CrudMapper;
import com.tmadmin.model.Client;
import com.tmadmin.repository.ClientRepository;
import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@FieldDefaults(level = AccessLevel.PRIVATE)
public class ClientService extends CrudService<Client, ClientDto> {

    public ClientService(ClientRepository clientRepository, ClientMapper clientMapper) {
        super(clientRepository, clientMapper);
    }

}
