package com.tmadmin.service;

import com.tmadmin.dto.ProxyDto;
import com.tmadmin.mapper.ProxyMapper;
import com.tmadmin.model.Proxy;
import com.tmadmin.repository.ProxyRepository;
import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@FieldDefaults(level = AccessLevel.PRIVATE)
public class ProxyService extends CrudService<Proxy, ProxyDto> {

    public ProxyService(ProxyRepository proxyRepository, ProxyMapper proxyMapper) {
        super(proxyRepository, proxyMapper);
    }

}
