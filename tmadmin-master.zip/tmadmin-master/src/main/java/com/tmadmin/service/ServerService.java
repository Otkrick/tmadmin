package com.tmadmin.service;

import com.tmadmin.dto.ServerDto;
import com.tmadmin.exception.ResourceNotFoundException;
import com.tmadmin.mapper.ServerMapper;
import com.tmadmin.model.Server;
import com.tmadmin.repository.ServerRepository;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.experimental.FieldDefaults;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Slf4j
@AllArgsConstructor
@Service
@FieldDefaults(level = AccessLevel.PRIVATE)
public class ServerService {

    final ServerMapper serverMapper;
    final ServerRepository serverRepository;

    @Transactional
    public String saveNewServer(ServerDto serverDto) {
        return serverRepository.save(serverMapper.toModel(serverDto)).getName() + " saved!";
    }

    @Transactional
    public List<Server> getServerList() {
        return serverRepository.findAll();
    }

    @Transactional
    public String deleteServer(Long id) {
        serverRepository.deleteById(id);
        return "Server removed successfully";
    }

    @Transactional
    public void updateServer(Long id, ServerDto serverDto) {
        Optional<Server> serverOptional = serverRepository.findById(id);
        if (serverOptional.isPresent()) {
            Server server = serverMapper.toModel(serverDto);
            server.setId(id);
            serverRepository.save(server);
        } else {
            throw new ResourceNotFoundException("Server", "id", id);
        }
    }

    @Transactional
    public Server findServer(Long id) {
        return serverRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Server", "id", id));
    }

    @Transactional
    public List<Server> findAll() {
        return serverRepository.findAll();
    }

}
