package com.tmadmin.service;

import com.tmadmin.dto.UserDto;
import com.tmadmin.exception.ResourceNotFoundException;
import com.tmadmin.mapper.UserMapper;
import com.tmadmin.model.User;
import com.tmadmin.repository.UserRepository;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.experimental.FieldDefaults;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Slf4j
@AllArgsConstructor
@Service
@FieldDefaults(level = AccessLevel.PRIVATE)
public class UserService {

    final UserRepository userRepository;
    final UserMapper userMapper;

    @Transactional
    public List<User> findAll() {
        return userRepository.findAll();
    }

    @Transactional
    public String saveNewUser(UserDto userDto) {
        if (userRepository.findByUserName(userDto.getUserName()).isPresent()) {
            return "User with name " + userDto.getUserName() + " already exist. Choose another name!";
        }
        return userRepository.save(userMapper.toUser(userDto)).getUserName() + " saved!";
    }

    @Transactional
    public User findUser(Long id) {
        return userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User", "id", id));
    }

    @Transactional
    public void updateUser(Long id, UserDto userDto) {
        Optional<User> userOptional = userRepository.findById(id);
        if (userOptional.isPresent()) {
            User user = userMapper.toUser(userDto);
            user.setId(id);
            userRepository.save(user);
        } else {
            throw new ResourceNotFoundException("User", "id", id);
        }
    }

    @Transactional
    public String deleteServer(Long id) {
        userRepository.deleteById(id);
        return "User deleted!";
    }

}
