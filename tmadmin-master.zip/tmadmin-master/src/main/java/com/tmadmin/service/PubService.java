package com.tmadmin.service;

import com.tmadmin.dto.PubDto;
import com.tmadmin.mapper.PubMapper;
import com.tmadmin.model.Pub;
import com.tmadmin.repository.PubRepository;
import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@FieldDefaults(level = AccessLevel.PRIVATE)
public class PubService extends CrudService<Pub, PubDto> {

    final PubRepository pubRepository;

    public PubService(PubRepository pubRepository, PubMapper pubMapper) {
        super(pubRepository, pubMapper);
        this.pubRepository = pubRepository;
    }

    public String getFormattedList() {
        StringBuilder stringBuilder = new StringBuilder();
        pubRepository.findAll()
                .forEach(pub -> stringBuilder
                        .append(pub.getSubdomain())
                        .append("\t")
                        .append(pub.getDomain())
                        .append("\t")
                        .append(pub.getServer().getLink())
                        .append("\n"));
        return stringBuilder.toString();
    }

}
