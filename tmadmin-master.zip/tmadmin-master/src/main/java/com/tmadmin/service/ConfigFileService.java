package com.tmadmin.service;

import com.tmadmin.exception.ResourceNotFoundException;
import com.tmadmin.model.FileStore;
import com.tmadmin.repository.FileStoreRepository;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.experimental.FieldDefaults;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.io.FileUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.File;
import java.io.IOException;
import java.util.List;

@Slf4j
@AllArgsConstructor
@Service
@FieldDefaults(level = AccessLevel.PRIVATE)
public class ConfigFileService {

    final FileStoreRepository fileStoreRepository;

    @Transactional
    public File findFile(String sha, String uuidCut) {
        String uuidSearch = uuidCut + "%";
        List<String> uuidList = fileStoreRepository.findByUuidCut(uuidSearch);
        String uuid = uuidList.stream()
                .filter(id-> DigestUtils.sha1Hex(id).equals(sha))
                .findAny().orElseThrow(()->
                        new ResourceNotFoundException("File", "uuid", uuidCut)
                );
        FileStore fileStore = fileStoreRepository.findByUuid(uuid).orElseThrow(()->
                new ResourceNotFoundException("File", "uuid", uuid));
        byte[] data = fileStore.getData();
        try {
            File file = new File(fileStore.getPath());
            FileUtils.writeByteArrayToFile(file, data);
            return file;
        } catch (IOException e) {
            throw new ResourceNotFoundException("File", "uuid", uuid);
        }
    }

}
