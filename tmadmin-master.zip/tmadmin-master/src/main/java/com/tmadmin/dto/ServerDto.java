package com.tmadmin.dto;

import lombok.AccessLevel;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

import javax.validation.constraints.Pattern;

@Getter
@Setter
@EqualsAndHashCode
@FieldDefaults(level = AccessLevel.PRIVATE)
public class ServerDto {

    @Pattern(regexp = "[A-Za-z0-9]+", message = "Name can contain only numbers or latin letters")
    String name;
    String proto;
    String domain;
    String port;
    String status;
    String osIp;
    String osPort;
    String osLogin;
    String osUuid;
    String osPassword;
}
