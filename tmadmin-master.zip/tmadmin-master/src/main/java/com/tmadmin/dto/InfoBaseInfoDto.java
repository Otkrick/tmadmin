package com.tmadmin.dto;

import lombok.AccessLevel;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

import java.time.Instant;
import java.util.UUID;

@Getter
@Setter
@EqualsAndHashCode
@FieldDefaults(level = AccessLevel.PRIVATE)
public class InfoBaseInfoDto {

    UUID infoBaseId;
    String name;
    String dbms;
    String dbName;
    String dbPassword;
    String dbServerName;
    String dbUser;
    Instant deniedFrom;
    String deniedMessage;
    String deniedParameter;
    Instant deniedTo;
    Integer dateOffset;
    String locale;
    String permissionCode;
    Boolean scheduledJobsDenied;
    Integer securityLevel;
    Boolean sessionsDenied;
    Integer licenseDistributionAllowed;
    String externalSessionManagerConnectionString;
    Boolean externalSessionManagerRequired;
    String descr;
    String securityProfileName;
    String safeModeSecurityProfileName;

}
