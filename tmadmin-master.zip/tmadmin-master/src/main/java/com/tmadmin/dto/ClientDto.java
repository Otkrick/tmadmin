package com.tmadmin.dto;

import lombok.AccessLevel;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

@Getter
@Setter
@EqualsAndHashCode
@FieldDefaults(level = AccessLevel.PRIVATE)
public class ClientDto {

    @Pattern(regexp = "[0-9]+", message = "TIN can contain only numbers")
    @Size(min = 10, max = 10, message = "Length should be 10 digits")
    String tin;
    String name;

}
