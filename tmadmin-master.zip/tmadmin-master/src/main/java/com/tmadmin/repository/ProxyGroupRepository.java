package com.tmadmin.repository;

import com.tmadmin.model.ProxyGroup;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ProxyGroupRepository extends JpaRepository<ProxyGroup, Long> {
}
