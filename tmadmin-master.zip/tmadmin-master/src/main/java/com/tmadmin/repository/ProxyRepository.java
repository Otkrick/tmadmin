package com.tmadmin.repository;

import com.tmadmin.dto.proxygroup.ProxyId;
import com.tmadmin.model.Proxy;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface ProxyRepository extends JpaRepository<Proxy, Long> {
}
