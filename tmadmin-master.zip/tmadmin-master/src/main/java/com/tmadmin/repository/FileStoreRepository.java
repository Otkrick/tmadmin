package com.tmadmin.repository;

import com.tmadmin.model.FileStore;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface FileStoreRepository extends JpaRepository<FileStore, Long> {

    Optional<FileStore> findByUuid(String uuid);

    @Query(value = "SELECT file_store.uuid FROM file_store WHERE file_store.uuid LIKE ?1", nativeQuery = true)
    List<String> findByUuidCut(String uuidCut);
}
