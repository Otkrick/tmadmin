package com.tmadmin.mapper;

import com.tmadmin.dto.ServerDto;
import com.tmadmin.model.Server;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.experimental.FieldDefaults;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

@Slf4j
@AllArgsConstructor
@Component
@FieldDefaults(level = AccessLevel.PRIVATE)
public class ServerMapper implements CrudMapper<Server, ServerDto> {

    final ModelMapper modelMapper = new ModelMapper();

    @Override
    public Server toModel(ServerDto dto) {
        return modelMapper.map(dto, Server.class);
    }

}
