package com.tmadmin.mapper;

import com._1c.v8.ibis.admin.InfoBaseInfo;
import com.tmadmin.dto.InfoBaseInfoDto;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.experimental.FieldDefaults;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

@Slf4j
@AllArgsConstructor
@Component
@FieldDefaults(level = AccessLevel.PRIVATE)
public class InfoBaseInfoMapper {

    final ModelMapper modelMapper = new ModelMapper();

    public InfoBaseInfo toModel(InfoBaseInfoDto dto) {
        return modelMapper.map(dto, InfoBaseInfo.class);
    }

}
