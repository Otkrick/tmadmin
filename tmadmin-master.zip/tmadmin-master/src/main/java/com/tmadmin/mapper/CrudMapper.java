package com.tmadmin.mapper;

public interface CrudMapper<T, D> {

    public T toModel(D dto);

}