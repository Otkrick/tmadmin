package com.tmadmin.mapper;

import com.tmadmin.dto.ProxyDto;
import com.tmadmin.model.Proxy;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.experimental.FieldDefaults;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

@Slf4j
@AllArgsConstructor
@Component
@FieldDefaults(level = AccessLevel.PRIVATE)
public class ProxyMapper implements CrudMapper<Proxy, ProxyDto> {

    final ModelMapper modelMapper = new ModelMapper();

    @Override
    public Proxy toModel(ProxyDto dto) {
        return modelMapper.map(dto, Proxy.class);
    }
}
