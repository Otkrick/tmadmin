package com.tmadmin.mapper;

import com.tmadmin.dto.ContainerDto;
import com.tmadmin.model.Container;
import org.modelmapper.ModelMapper;

public class ContainerMapper implements CrudMapper<Container, ContainerDto> {

    final ModelMapper modelMapper = new ModelMapper();

    @Override
    public Container toModel(ContainerDto dto) {
        return modelMapper.map(dto, Container.class);
    }

}
