package com.tmadmin.mapper;

import com.tmadmin.dto.proxygroup.ProxyGroupDto;
import com.tmadmin.model.ProxyGroup;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.experimental.FieldDefaults;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

@Slf4j
@AllArgsConstructor
@Component
@FieldDefaults(level = AccessLevel.PRIVATE)
public class ProxyGroupMapper implements CrudMapper<ProxyGroup, ProxyGroupDto> {

    final ModelMapper modelMapper = new ModelMapper();

    @Override
    public ProxyGroup toModel(ProxyGroupDto dto) {
        return modelMapper.map(dto, ProxyGroup.class);
    }

}
