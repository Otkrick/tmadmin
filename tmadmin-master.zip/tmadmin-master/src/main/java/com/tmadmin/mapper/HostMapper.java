package com.tmadmin.mapper;

import com.tmadmin.dto.HostDto;
import com.tmadmin.model.Host;
import org.modelmapper.ModelMapper;

public class HostMapper implements CrudMapper<Host, HostDto> {

    final ModelMapper modelMapper = new ModelMapper();

    @Override
    public Host toModel(HostDto dto) {
        return modelMapper.map(dto, Host.class);
    }
}
