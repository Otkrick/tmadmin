package com.tmadmin.mapper;

import com.tmadmin.dto.PubDto;
import com.tmadmin.exception.ResourceNotFoundException;
import com.tmadmin.model.Pub;
import com.tmadmin.repository.ProxyGroupRepository;
import com.tmadmin.repository.ServerRepository;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.experimental.FieldDefaults;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Slf4j
@AllArgsConstructor
@Component
@FieldDefaults(level = AccessLevel.PRIVATE)
public class PubMapper implements CrudMapper<Pub, PubDto> {

    final ServerRepository serverRepository;
    final ProxyGroupRepository proxyGroupRepository;

    @Override
    public Pub toModel(PubDto dto) {
        Pub pub = new Pub();
        pub.setDomain(dto.getDomain());
        pub.setSubdomain(dto.getSubdomain());
        pub.setServer(serverRepository.findById(dto.getServer_id()).orElseThrow(() ->
                new ResourceNotFoundException("Server", "id", dto.getServer_id())));
        pub.setProxyGroup(proxyGroupRepository.findById(dto.getProxyGroupId()).orElseThrow(() ->
                new ResourceNotFoundException("Proxy Group", "id", dto.getProxyGroupId())));
        pub.setProto(dto.getProto());
        pub.setPath(dto.getPath());
        pub.setOsUuid(dto.getOsUuid());
        pub.setOsLogin(dto.getOsLogin());
        pub.setOsPassword(dto.getOsPassword());
        return pub;
    }

}
