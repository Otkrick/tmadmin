package com.tmadmin.mapper;

import com.tmadmin.dto.ClientDto;
import com.tmadmin.model.Client;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.experimental.FieldDefaults;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

@Slf4j
@AllArgsConstructor
@Component
@FieldDefaults(level = AccessLevel.PRIVATE)
public class ClientMapper implements CrudMapper<Client, ClientDto> {

    final ModelMapper modelMapper = new ModelMapper();

    @Override
    public Client toModel(ClientDto dto) {
        return modelMapper.map(dto, Client.class);
    }
}
