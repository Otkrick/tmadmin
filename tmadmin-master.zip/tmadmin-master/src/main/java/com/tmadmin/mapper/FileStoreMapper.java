package com.tmadmin.mapper;

import com.tmadmin.dto.FileStoreDto;
import com.tmadmin.model.FileStore;
import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.codec.digest.DigestUtils;
import org.springframework.stereotype.Component;

@Slf4j
@Component
@FieldDefaults(level = AccessLevel.PRIVATE)
public class FileStoreMapper {

    public FileStoreDto toFileStoreDto(FileStore fileStore) {
        FileStoreDto fileStoreDto = new FileStoreDto();
        fileStoreDto.setPath(fileStore.getPath());
        fileStoreDto.setUuid(fileStore.getUuid());
        fileStoreDto.setSha(DigestUtils.sha1Hex(fileStore.getUuid()));
        return fileStoreDto;
    }

}
