package com.tmadmin.exception;

import com._1c.v8.ibis.admin.AgentAdminException;
import com.tmadmin.dto.ErrorMessageResponse;
import org.springframework.http.HttpStatus;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.util.HashMap;
import java.util.Map;

@RestControllerAdvice
public class GlobalHandler {

    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public Map<String, String> validationExceptionsHandler(MethodArgumentNotValidException exception) {
        Map<String, String> errors = new HashMap<>();
        exception.getBindingResult().getAllErrors()
                .forEach(error -> errors.put(((FieldError) error).getField(), error.getDefaultMessage()));
        return errors;
    }

    @ResponseStatus(HttpStatus.NOT_FOUND)
    @ExceptionHandler(ResourceNotFoundException.class)
    public ErrorMessageResponse resourceNotFoundExceptionHandler(ResourceNotFoundException exception) {
        return new ErrorMessageResponse(exception.getMessage());
    }

    @ResponseStatus(HttpStatus.I_AM_A_TEAPOT)
    @ExceptionHandler(IllegalStateException.class)
    public ErrorMessageResponse illegalStateExceptionExceptionHandler(IllegalStateException exception) {
        return new ErrorMessageResponse(exception.getMessage());
    }

    @ResponseStatus(HttpStatus.I_AM_A_TEAPOT)
    @ExceptionHandler(AgentAdminException.class)
    public ErrorMessageResponse agentAdminExceptionHandler(AgentAdminException exception) {
        return new ErrorMessageResponse(exception.getMessage());
    }

}
