package com.tmadmin.configuration;

import com.tmadmin.model.Credentials;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.ApplicationListener;
import org.springframework.security.authentication.event.AuthenticationSuccessEvent;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class AuthenticationSuccessListener implements ApplicationListener<AuthenticationSuccessEvent> {

    @Override
    public void onApplicationEvent(AuthenticationSuccessEvent appEvent) {
        UserDetails userDetails = (UserDetails) appEvent.getAuthentication().getPrincipal();
        if (userDetails instanceof Credentials) {
            log.info("Authentication Success with:\n" +
                    "Login = " + userDetails.getUsername());
        }
    }

}
