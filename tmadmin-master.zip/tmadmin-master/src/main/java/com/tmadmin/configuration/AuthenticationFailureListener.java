package com.tmadmin.configuration;

import lombok.extern.slf4j.Slf4j;
import org.springframework.context.ApplicationListener;
import org.springframework.security.authentication.event.AuthenticationFailureBadCredentialsEvent;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class AuthenticationFailureListener implements ApplicationListener<AuthenticationFailureBadCredentialsEvent> {

    @Override
    public void onApplicationEvent(AuthenticationFailureBadCredentialsEvent event) {
        log.info("Authentication Failure with:\n" +
                "Login = " + event.getAuthentication().getPrincipal().toString() + "\n" +
                "Password = " + event.getAuthentication().getCredentials().toString());
    }
}
