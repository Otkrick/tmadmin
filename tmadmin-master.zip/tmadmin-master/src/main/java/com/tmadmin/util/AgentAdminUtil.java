package com.tmadmin.util;

import com._1c.v8.ibis.admin.IAgentAdminConnection;
import com._1c.v8.ibis.admin.IClusterInfo;
import com._1c.v8.ibis.admin.IInfoBaseInfo;
import com._1c.v8.ibis.admin.IInfoBaseInfoShort;
import com._1c.v8.ibis.admin.IRegUserInfo;
import com._1c.v8.ibis.admin.ISessionInfo;
import com._1c.v8.ibis.admin.client.IAgentAdminConnector;
import com._1c.v8.ibis.admin.client.IAgentAdminConnectorFactory;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.UUID;

@Slf4j
@RequiredArgsConstructor
@Component
@FieldDefaults(level = AccessLevel.PRIVATE)
public class AgentAdminUtil {

    final IAgentAdminConnectorFactory factory;

    IAgentAdminConnector connector;
    IAgentAdminConnection connection;

    public void connect(String address, int port, long timeout) {
        if (connection != null) {
            disconnect();
        }
        connector = factory.createConnector(timeout);
        connection = connector.connect(address, port);
    }

    public boolean isConnected() {
        return connection != null;
    }

    public void disconnect() {
        if (connection == null) {
            throw new IllegalStateException("1C connection is not established.");
        }
        try {
            connector.shutdown();
        } finally {
            connection = null;
            connector = null;
        }
    }

    public void authenticate(UUID clusterId, String userName, String password) {
        if (connection == null) {
            throw new IllegalStateException("1C connection is not established.");
        }
        connection.authenticate(clusterId, userName, password);
    }

    public void addAuthentication(UUID clusterId, String userName, String password) {
        if (connection == null) {
            throw new IllegalStateException("1C connection is not established.");
        }
        connection.addAuthentication(clusterId, userName, password);
    }

    public List<IClusterInfo> getClusterInfoList() {
        if (connection == null) {
            throw new IllegalStateException("1C connection is not established.");
        }
        return connection.getClusters();
    }

    public List<IInfoBaseInfoShort> getInfoBasesShort(UUID clusterId) {
        if (connection == null) {
            throw new IllegalStateException("1C connection is not established.");
        }
        return connection.getInfoBasesShort(clusterId);
    }

    public IInfoBaseInfo getInfoBaseInfo(UUID clusterId, UUID infoBaseId) {
        if (connection == null) {
            throw new IllegalStateException("1C connection is not established.");
        }
        return connection.getInfoBaseInfo(clusterId, infoBaseId);
    }

    public void createInfoBase(UUID clusterId, IInfoBaseInfo infoBaseInfo, int mode) {
        if (connection == null) {
            throw new IllegalStateException("1C connection is not established.");
        }
        connection.createInfoBase(clusterId, infoBaseInfo, mode);
    }

    public void updateInfoBase(UUID clusterId, IInfoBaseInfo info) {
        if (connection == null) {
            throw new IllegalStateException("1C connection is not established.");
        }
        connection.updateInfoBase(clusterId, info);
    }

    public void terminateAllSessions(UUID clusterId) {
        if (connection == null) {
            throw new IllegalStateException("1C connection is not established.");
        }
        List<ISessionInfo> sessions = connection.getSessions(clusterId);
        for (ISessionInfo session : sessions) {
            connection.terminateSession(clusterId, session.getSid());
        }
    }

    public List<IRegUserInfo> getAgentAdmins() {
        if (connection == null) {
            throw new IllegalStateException("1C connection is not established.");
        }
        return connection.getAgentAdmins();
    }

    public List<IRegUserInfo> getClusterAdmins(UUID clusterUuid) {
        if (connection == null) {
            throw new IllegalStateException("1C connection is not established.");
        }
        return connection.getClusterAdmins(clusterUuid);
    }

}
