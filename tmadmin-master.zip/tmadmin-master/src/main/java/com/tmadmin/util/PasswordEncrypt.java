package com.tmadmin.util;

import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;
import org.jasypt.util.text.BasicTextEncryptor;

@FieldDefaults(level = AccessLevel.PRIVATE)
public class PasswordEncrypt {

    final static String KEY = "FDS&F*)AS-DF&AS*F&ASD";

    public static String encrypt(String password) {
        BasicTextEncryptor encryptor = new BasicTextEncryptor();
        encryptor.setPassword(KEY);
        return encryptor.encrypt(password);
    }

    public static String decrypt(String password) {
        BasicTextEncryptor encryptor = new BasicTextEncryptor();
        encryptor.setPassword(KEY);
        return encryptor.decrypt(password);
    }

}
