package com.tmadmin.util;

import com._1c.v8.ibis.admin.client.AgentAdminConnector;
import com._1c.v8.ibis.admin.client.IAgentAdminConnector;
import com._1c.v8.ibis.admin.client.IAgentAdminConnectorFactory;
import org.springframework.stereotype.Component;

import java.util.Timer;
import java.util.concurrent.Executor;

@Component
public class AgentAdminConnectorFactory implements IAgentAdminConnectorFactory {

    public IAgentAdminConnector createConnector(long connectTimeout) {
        return new AgentAdminConnector(connectTimeout);
    }

    public IAgentAdminConnector createConnector(Timer timer, Executor executor, long connectTimeout) {
        return new AgentAdminConnector(timer, executor, connectTimeout);
    }
}
