package com.tmadmin.controller;

import com.tmadmin.dto.ProxyDto;
import com.tmadmin.model.Proxy;
import com.tmadmin.service.ProxyService;
import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@FieldDefaults(level = AccessLevel.PRIVATE)
@RequestMapping("/proxy")
public class ProxyController extends CrudController<Proxy, ProxyDto> {

    public ProxyController(ProxyService proxyService) {
        super(proxyService);
    }

}
