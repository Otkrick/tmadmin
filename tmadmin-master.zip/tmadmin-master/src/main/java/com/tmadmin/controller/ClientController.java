package com.tmadmin.controller;

import com.tmadmin.dto.ClientDto;
import com.tmadmin.model.Client;
import com.tmadmin.service.ClientService;
import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@FieldDefaults(level = AccessLevel.PRIVATE)
@RequestMapping("/client")
public class ClientController extends CrudController<Client, ClientDto> {

    public ClientController(ClientService clientService) {
        super(clientService);
    }

}
