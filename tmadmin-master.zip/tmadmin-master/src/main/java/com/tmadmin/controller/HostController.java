package com.tmadmin.controller;

import com.tmadmin.dto.HostDto;
import com.tmadmin.model.Host;
import com.tmadmin.service.HostService;
import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@FieldDefaults(level = AccessLevel.PRIVATE)
@RequestMapping("/host")
public class HostController extends CrudController<Host, HostDto> {

    public HostController(HostService hostService) {
        super(hostService);
    }

}
