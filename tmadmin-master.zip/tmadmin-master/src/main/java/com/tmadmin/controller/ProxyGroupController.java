package com.tmadmin.controller;

import com.tmadmin.dto.MessageResponse;
import com.tmadmin.dto.proxygroup.ProxyGroupDto;
import com.tmadmin.dto.proxygroup.ProxyId;
import com.tmadmin.model.ProxyGroup;
import com.tmadmin.service.ProxyGroupService;
import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Slf4j
@RestController
@FieldDefaults(level = AccessLevel.PRIVATE)
@RequestMapping("/proxy/group")
public class ProxyGroupController extends CrudController<ProxyGroup, ProxyGroupDto> {

    final ProxyGroupService proxyGroupService;

    public ProxyGroupController(ProxyGroupService proxyGroupService) {
        super(proxyGroupService);
        this.proxyGroupService = proxyGroupService;
    }

    @DeleteMapping("/delete/proxy/{id}")
    public ResponseEntity<MessageResponse> deleteProxyFromGroup(@PathVariable Long id,
            @RequestBody List<ProxyId> proxyId){
        return ResponseEntity.ok(new MessageResponse(proxyGroupService.deleteProxyFromList(id, proxyId)));
    }

    @PutMapping("/add/proxy/{id}")
    public ResponseEntity<MessageResponse> addProxyToGroup(@PathVariable Long id,
                                                           @RequestBody List<ProxyId> proxyId){
        return ResponseEntity.ok(new MessageResponse(proxyGroupService.addProxyToList(id, proxyId)));
    }

}
