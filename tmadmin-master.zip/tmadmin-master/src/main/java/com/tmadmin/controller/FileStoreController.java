package com.tmadmin.controller;

import com.tmadmin.dto.FileStoreDto;
import com.tmadmin.service.FileStoreService;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.experimental.FieldDefaults;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.List;

@Slf4j
@AllArgsConstructor
@RestController
@FieldDefaults(level = AccessLevel.PRIVATE)
@RequestMapping("/file_store")
public class FileStoreController {

    final FileStoreService fileStoreService;

    @PostMapping(value = "/upload", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<String> uploadFile(@RequestParam(required = false) Boolean config,
                                             @RequestPart("file") MultipartFile multipartFile) {
        fileStoreService.saveFile(multipartFile, config);
        return ResponseEntity.ok("File uploaded");
    }

    @GetMapping("/download")
    public ResponseEntity<Resource> downloadFile(@RequestParam String id)
            throws FileNotFoundException {
        File file = fileStoreService.findFile(id);
        InputStreamResource resource = new InputStreamResource(new FileInputStream(file));
        return ResponseEntity.ok()
                .contentLength(file.length())
                .contentType(MediaType.parseMediaType("application/octet-stream"))
                .body(resource);
    }

    @GetMapping("/file_list")
    public ResponseEntity<List<FileStoreDto>> findAllFiles() {
        return ResponseEntity.ok(fileStoreService.findAll());
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<String> delete(@PathVariable Long id) {
        fileStoreService.delete(id);
        return ResponseEntity.ok("Deleted");
    }

}
