package com.tmadmin.controller;

import com.tmadmin.dto.PubDto;
import com.tmadmin.model.Pub;
import com.tmadmin.service.PubService;
import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@FieldDefaults(level = AccessLevel.PRIVATE)
@RequestMapping("/pub")
public class PubController extends CrudController<Pub, PubDto> {

    final PubService pubService;

    public PubController(PubService pubService) {
        super(pubService);
        this.pubService = pubService;
    }

    @GetMapping("/formatted")
    public String getFormattedList(){
        return pubService.getFormattedList();
    }
}
