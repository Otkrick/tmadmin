package com.tmadmin.controller;

import com.tmadmin.dto.ServerDto;
import com.tmadmin.model.Server;
import com.tmadmin.service.ServerService;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.experimental.FieldDefaults;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import javax.validation.Valid;
import java.util.List;

@Slf4j
@AllArgsConstructor
@RestController
@FieldDefaults(level = AccessLevel.PRIVATE)
@RequestMapping("/server")
public class ServerController {

    ServerService serverService;

    @GetMapping("/view/all")
    public ModelAndView getServerList(ModelAndView modelAndView) {
        modelAndView.setViewName("main_page");
        modelAndView.addObject("serverList", serverService.getServerList());
        return modelAndView;
    }

    @GetMapping("/all")
    public ResponseEntity<List<Server>> findAll() {
        return ResponseEntity.ok(serverService.findAll());
    }

    @PostMapping("/new")
    public ResponseEntity<String> saveNewServer(@Valid @RequestBody ServerDto serverDto) {
        return ResponseEntity.ok(serverService.saveNewServer(serverDto));
    }

    @GetMapping("/{id}")
    public ResponseEntity<Server> findServer(@PathVariable Long id) {
        return ResponseEntity.ok(serverService.findServer(id));
    }

    @PutMapping("/update/{id}")
    public ResponseEntity<String> updateServer(@PathVariable Long id,
                                               @Valid @RequestBody ServerDto serverDto) {
        serverService.updateServer(id, serverDto);
        return ResponseEntity.ok("Updated");
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteServer(@PathVariable Long id) {
        return ResponseEntity.ok(serverService.deleteServer(id));
    }

}
