package com.tmadmin.controller;

import com._1c.v8.ibis.admin.IClusterInfo;
import com._1c.v8.ibis.admin.IInfoBaseInfo;
import com._1c.v8.ibis.admin.IInfoBaseInfoShort;
import com.tmadmin.dto.EnterpriseDto;
import com.tmadmin.dto.InfoBaseInfoDto;
import com.tmadmin.dto.MessageResponse;
import com.tmadmin.service.EnterpriseService;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.experimental.FieldDefaults;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Slf4j
@RestController
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
@RequestMapping("/enterprise")
public class EnterpriseController {

    final EnterpriseService enterpriseService;

    @GetMapping
    public ResponseEntity<List<IClusterInfo>> getClusterInfo() {
        return ResponseEntity.ok(enterpriseService.getClusterInfoList());
    }

    @GetMapping("/infoBase")
    public ResponseEntity<IInfoBaseInfo> getBaseInfo(@RequestParam String clusterId,
                                                     @RequestParam String infoBaseId) {
        return ResponseEntity.ok(enterpriseService.getBaseInfo(clusterId, infoBaseId));
    }

    @PostMapping("/infoBase/new")
    public ResponseEntity<MessageResponse> createInfoBase(@RequestBody InfoBaseInfoDto infoBaseInfoDto){
        enterpriseService.createInfoBase(infoBaseInfoDto);
        return ResponseEntity.ok(new MessageResponse("InfoBase created"));
    }

    @PostMapping
    public ResponseEntity<List<IInfoBaseInfoShort>> getBaseInfoShort(@RequestBody EnterpriseDto enterpriseDto) {
        return ResponseEntity.ok(enterpriseService.getBaseInfoShort(enterpriseDto));
    }

}
