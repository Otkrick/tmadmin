package com.tmadmin.controller;

import com.tmadmin.dto.ContainerDto;
import com.tmadmin.model.Container;
import com.tmadmin.service.ContainerService;
import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@FieldDefaults(level = AccessLevel.PRIVATE)
@RequestMapping("/container")
public class ContainerController extends CrudController<Container, ContainerDto> {

    public ContainerController(ContainerService containerService) {
        super(containerService);
    }

}
