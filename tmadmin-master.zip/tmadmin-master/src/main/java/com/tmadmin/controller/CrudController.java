package com.tmadmin.controller;

import com.tmadmin.dto.MessageResponse;
import com.tmadmin.model.BaseModel;
import com.tmadmin.service.CrudService;
import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import javax.validation.Valid;
import java.util.List;


@FieldDefaults(level = AccessLevel.PRIVATE)
public abstract class CrudController<T extends BaseModel, D> {

    final CrudService<T, D> crudService;

    @Autowired
    public CrudController(CrudService<T, D> crudService) {
        this.crudService = crudService;
    }

    @GetMapping("/all")
    public ResponseEntity<List<T>> findAll() {
        return ResponseEntity.ok(crudService.findAll());
    }

    @PostMapping("/new")
    public ResponseEntity<MessageResponse> saveNew(@Valid @RequestBody D dto) {
        return ResponseEntity.ok(new MessageResponse(crudService.saveNew(dto)));
    }

    @GetMapping("/{id}")
    public ResponseEntity<T> findById(@PathVariable Long id) {
        return ResponseEntity.ok(crudService.findById(id));
    }

    @PutMapping("/update/{id}")
    public ResponseEntity<MessageResponse> updateById(@PathVariable Long id,
                                                      @RequestBody D dto) {
        return ResponseEntity.ok(new MessageResponse(crudService.update(id, dto)));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<MessageResponse> deleteById(@PathVariable Long id) {
        return ResponseEntity.ok(new MessageResponse(crudService.delete(id)));
    }

}
