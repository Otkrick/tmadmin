package com.tmadmin.model;

import com.tmadmin.util.PasswordEncrypt;
import lombok.AccessLevel;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
@Getter
@Setter
@EqualsAndHashCode
@FieldDefaults(level = AccessLevel.PRIVATE)
public class Host implements BaseModel{

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    long id;

    String hostname;
    String ip;
    String port;

    @Column(name = "api_user")
    String apiUser;

    @Column(name = "api_password")
    @Getter(AccessLevel.NONE)
    @Setter(AccessLevel.NONE)
    String apiPassword;

    String memo;

    public String getApiPassword() {
        return PasswordEncrypt.decrypt(apiPassword);
    }

    public void setApiPassword(String osPassword) {
        this.apiPassword = PasswordEncrypt.encrypt(osPassword);
    }

}
