package com.tmadmin.model;

import com.tmadmin.util.PasswordEncrypt;
import lombok.AccessLevel;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
@Getter
@Setter
@EqualsAndHashCode
@FieldDefaults(level = AccessLevel.PRIVATE)
public class Container implements BaseModel {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    long id;

    int vmid;
    String node;

    @Column(name = "api_user")
    String apiUser;

    @Getter(AccessLevel.NONE)
    @Setter(AccessLevel.NONE)
    String password;

    String hostname;

    @Column(name = "os_template")
    String osTemplate;
    String neif;
    String state;

    public String getPassword() {
        return PasswordEncrypt.decrypt(password);
    }

    public void setPassword(String osPassword) {
        this.password = PasswordEncrypt.encrypt(osPassword);
    }

}
