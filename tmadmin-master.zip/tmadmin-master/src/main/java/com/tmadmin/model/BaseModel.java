package com.tmadmin.model;

public interface BaseModel {

    void setId(long id);

}
