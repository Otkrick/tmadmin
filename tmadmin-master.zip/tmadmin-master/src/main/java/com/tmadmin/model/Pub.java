package com.tmadmin.model;

import com.tmadmin.util.PasswordEncrypt;
import lombok.AccessLevel;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity
@Getter
@Setter
@EqualsAndHashCode
@FieldDefaults(level = AccessLevel.PRIVATE)
public class Pub implements BaseModel {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    long id;

    String domain;
    String subdomain;

    @OneToOne
    @JoinColumn(name = "server_id", referencedColumnName = "id")
    Server server;

    @OneToOne
    @JoinColumn(name = "proxy_group_id", referencedColumnName = "id")
    ProxyGroup proxyGroup;

    String proto;
    String path;
    String osUuid;
    String osLogin;

    @Setter(AccessLevel.NONE)
    @Getter(AccessLevel.NONE)
    String osPassword;

    public String getOsPassword() {
        return PasswordEncrypt.decrypt(osPassword);
    }

    public void setOsPassword(String osPassword) {
        this.osPassword = PasswordEncrypt.encrypt(osPassword);
    }

}
