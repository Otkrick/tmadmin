package com.tmadmin.model;

import com.tmadmin.util.PasswordEncrypt;
import lombok.AccessLevel;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
@Getter
@Setter
@EqualsAndHashCode
@FieldDefaults(level = AccessLevel.PRIVATE)
public class Server {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    long id;
    String name;
    String proto;
    String domain;
    String port;
    String status;
    String osIp;
    String osPort;
    String osLogin;
    String osUuid;

    @Getter(AccessLevel.NONE)
    @Setter(AccessLevel.NONE)
    String osPassword;

    public String getLink() {
        if (port == null || "".equals(port)) {
            return proto + "://" + name + "." + domain + "/";
        }
        return proto + "://" + name + "." + domain + ":" + port + "/";
    }

    public String getOsPassword() {
        return PasswordEncrypt.decrypt(osPassword);
    }

    public void setOsPassword(String osPassword) {
        this.osPassword = PasswordEncrypt.encrypt(osPassword);
    }

}
