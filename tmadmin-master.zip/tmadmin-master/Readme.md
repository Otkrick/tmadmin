Input in terminal

- to run app `mvn spring-boot:run`
    
- to create WAR file `mvn compile war:war` or `mvn clean install`

WAR file location `/target/tmadmin.war`


** test for commit
=======
**Swagger:**
http://localhost:8080/swagger-ui.html

Server API:

get list of servers: http://localhost:8080/server/all
GET method

create server: http://localhost:8080/server/new
POST method
body: {
    "name":" ",
    "proto":" ",
    "domain:" ",
    "port":" ",
    "status":" "
}

update server: http://localhost:8080/server/update/{id}
PUT method
body: {
    "id":" ",
    "name":" ",
    "proto":" ",
    "domain:" ",
    "port":" ",
    "status":" "
}

get server by id: http://localhost:8080/server/{id}
GET method

delete server by id: http://localhost:8080/server/{id}
DELETE method

File_store API:

get list of files: http://localhost:8080/file_store/file_list
GET method

upload file: http://localhost:8080/file_store/upload
POST method

download file: http://localhost:8080/file_store/download?id=uuid
GET method

delete file: http://localhost:8080/file_store/delete/{id}
DELETE method

User API:

List of users: http://localhost:8080/user/all
GET method

Create user: http://localhost:8080/user/new
POST method
body: {
       "userName":" ",
        "password":" ",
        "token":" "
}

Update user: http://localhost:8080/user/{id}
PUT method
body: {
       "id":" ",
       "userName":" ",
        "password":" ",
        "token":" "
}

Find user by id: http://localhost:8080/user/{id}
GET method

Delete user by id: http://localhost:8080/user/{id}
DELETE method

